
clear;
format long g;
data=importdata('Building_Permits.csv');
p_index=1;
No_attribute=1;
attribute_total= data.textdata{1,1};
for j=1:length(attribute_total)
    if attribute_total(j) == ','
        attribute{No_attribute}=attribute_total(p_index:j-1);
        p_index=j+1;
        No_attribute=No_attribute+1;
    end
end
attribute{No_attribute}=attribute_total(p_index:end);
data.textdata(1,:)=[];
all_data=cell(198900,43);
all_data(:,1:42)=data.textdata;
all_data(:,43)=num2cell(data.data);
attribute_value = {'Number of Existing Stories'; 'Number of Proposed Stories'; 'Estimated Cost'; 'Revised Cost'; 'Existing Units'; 'Proposed Units'}; 
attribute_nominal_no = {'Permit Number'; 'Permit Creation Date'; 'Block'; 'Lot'; 'Street Number'; 'Street Number Suffix';'Street Name';'Street Suffix';'Unit';'Unit Suffix';'Description';'Current Status';'Current Status Date';'Filed Date';'Issued Date';'Completed Date';'First Construction Document Date';'Structural Notification';'Voluntary Soft-Story Retrofit';'Fire Only Permit';'Permit Expiration Date';'Existing Use';'Proposed Use';'Plansets';'TIDF Compliance';'Site Permit';'Supervisor District';'Neighborhoods - Analysis Boundaries';'Zipcode';'Location';'Record ID'}; 
attribute_nominal_1 = {'Permit Type'; 'Existing Construction Type'; 'Proposed Construction Type'}; 
attribute_nominal_2 = {'Permit Type Definition'; 'Existing Construction Type Description'; 'Proposed Construction Type Description'}; 
if ~exist('processed_permits.mat','file')
    all_attribute_value=NaN*ones(198900,43);
else
    load('processed_permits.mat');
end

for i=1:length(attribute_nominal_no)
    now_no_attribute=find(strcmp(attribute,attribute_nominal_no{i}));
    now_attribute=all_data(:,now_no_attribute);
    raw_now_attribute=now_attribute;
    if isa (now_attribute{1},'double')
        now_attribute=cell2mat(now_attribute);
        now_attribute=num2str(now_attribute);
        [row,col]=size(now_attribute);
        now_attribute=mat2cell(now_attribute,ones(row,1),[col]);
    end
    now_attribute(strcmp(now_attribute,''))=[];
    unique_now_attribute=unique(now_attribute);
    save(['Nominal2Category_Label\',attribute_nominal_no{i},'.mat'],'unique_now_attribute')
    unique_now_attribute_num=zeros(length(unique_now_attribute),1);
    for j=1:length(unique_now_attribute)
        unique_now_attribute_num(j)=length(find(strcmp(now_attribute,unique_now_attribute(j))));
        if ~exist('processed_permits.mat','file')
            all_attribute_value(strcmp(raw_now_attribute,unique_now_attribute{j}),now_no_attribute)=j;
        end
        fprintf('Task1:i=%d,j=%d,totali=%d,totalj=%d\n',i,j,length(attribute_nominal_no),length(unique_now_attribute))
    end
    total_num=sum(unique_now_attribute_num);

    if length(unique_now_attribute)>1000
        continue;
    end
    file_name=attribute_nominal_no{i};
    fid = fopen(['attribute_nominal_no\',file_name,'.txt'],'w');
    fprintf(fid,'frequence of %s attribute\n',file_name);
    fprintf(fid,'%20s      %20s      %20s\n','Type Description','Count','Percent');
    for j=1:length(unique_now_attribute)
    fprintf(fid,'%20s      %20d      %20.2f%%\n',unique_now_attribute{j},unique_now_attribute_num(j),100*unique_now_attribute_num(j)/total_num);
    end
    fclose(fid);
    fprintf('%d,%s\n',i,file_name);
end
for i=1:length(attribute_nominal_1)
    now_no_attribute=find(strcmp(attribute,attribute_nominal_1{i}));
    now_no_attribute_type_description=find(strcmp(attribute,attribute_nominal_2{i}));
    now_attribute=all_data(:,now_no_attribute);
    now_attribute(strcmp(now_attribute,''))={'nan'};
    raw_now_attribute=now_attribute;
    now_attribute_type_description=all_data(:,now_no_attribute_type_description);
    if isa (now_attribute{1},'double')
        now_attribute=cell2mat(now_attribute);
        now_attribute=num2str(now_attribute);
        [row,col]=size(now_attribute);
        now_attribute=mat2cell(now_attribute,ones(row,1),[col]);
    end
    now_attribute(strcmp(now_attribute,''))=[];
    unique_now_attribute=unique(now_attribute);
    unique_now_attribute_num=zeros(length(unique_now_attribute),1);

    for j=1:length(unique_now_attribute)
        unique_now_attribute_num(j)=length(find(strcmp(now_attribute,unique_now_attribute(j))));
    end
    if ~exist('processed_permits.mat','file')
        all_attribute_value(:,now_no_attribute)=str2double(now_attribute);
        all_attribute_value(:,now_no_attribute_type_description)=str2double(now_attribute);
    end
    if length(unique_now_attribute)>1000
        continue;
    end
    total_num=sum(unique_now_attribute_num);
    file_name=attribute_nominal_1{i};
    fid = fopen(['attribute_nominal_1\',file_name,'.txt'],'w');
    fprintf(fid,'frequence of %s attribute\n',file_name);
    fprintf(fid,'%10s      %40s      %10s      %10s\n','Value','Type Description','Count','Percent');
    for j=1:length(unique_now_attribute)
       index=find(strcmp(raw_now_attribute,unique_now_attribute{j}));
      current_typedefine=now_attribute_type_description{index(1)};
      fprintf(fid,'%10s      %40s      %10d      %10.2f%%\n',unique_now_attribute{j},current_typedefine,unique_now_attribute_num(j),100*unique_now_attribute_num(j)/total_num);
    end
    fclose(fid);
    fprintf('%d,%s\n',i,file_name);
end
for i=1:length(attribute_value)
    now_no_attribute=find(strcmp(attribute,attribute_value{i}));
    now_attribute=all_data(:,now_no_attribute);
    now_attribute(strcmp(now_attribute,''))={'nan'};
    now_attribute=str2double(now_attribute);
    if ~exist('processed_permits.mat','file')
        all_attribute_value(:,now_no_attribute)=now_attribute;
    end
    temp_data = now_attribute;
    [NaN_line, ~] = find(isnan(temp_data) == 1);
    temp_data(NaN_line, :) = [];
    disp(['Data abstract of attribute ', attribute_value{i}, ':']);
    disp(['  Maximium:     ', num2str(max(temp_data))]); % ���ֵ
    disp(['  Minimium:     ', num2str(min(temp_data))]); % ��Сֵ
    disp(['  Average:      ', num2str(sum(temp_data) / size(temp_data, 1))]); % ƽ��ֵ
    disp(['  Median:       ', num2str(median(temp_data))]); % ��λ��
    disp(['  Quartile:     ', num2str(prctile(temp_data,25)), ', ', num2str(prctile(temp_data,75))]); % �ķ�λ��
    disp(['  Missing data: ', num2str(size(NaN_line, 1))]); % ȱʧֵ����
    disp(' ');
end
if ~exist('processed_permits.mat','file')
    all_attribute_value(:,43)=all_data{:,43};
    save('processed_permits','all_attribute_value');
end
myvisualization(all_attribute_value,attribute);
while(1)
    disp('Choose one way to fill the missing data:');
    disp('(1 - filled by maxium; 2 - filled by attributes; 3 - filled by similarity; any other key - end program)');
    method = input('');
    
    switch(method)
        case 1
            data = mypreprocessing(all_attribute_value, 1);
            dlmwrite('building_permits_filled_by_maximium.txt', data, 'delimiter', '\t','precision', 6,'newline', 'pc')
            myvisualization(data,attribute);
        case 2
            data2 = mypreprocessing(all_attribute_value, 2);
            dlmwrite('building_permits_filled_by_attribute.txt', data2, 'delimiter', '\t','precision', 6,'newline', 'pc')
            myvisualization(data2);
        case 3
            data3=zeros(198900,43);
            blocksize=300;
            for k=1:blocksize
                disp(k)
                block_all_attribute_value=all_attribute_value((198900/blocksize)*(k-1)+1:(198900/blocksize)*k,:);
                data3((198900/blocksize)*(k-1)+1:(198900/blocksize)*k,:) = mypreprocessing(block_all_attribute_value, 3);
            end
            dlmwrite('building_permits_filled_by_similarity.txt', data3, 'delimiter', '\t','precision', 6,'newline', 'pc')
            myvisualization(data3);
        otherwise
            break;
    end
end

