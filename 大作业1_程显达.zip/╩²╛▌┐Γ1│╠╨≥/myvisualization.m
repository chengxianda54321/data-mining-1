%%
%visualization
function myvisualization(path,totaldata,attribute,ATTRIBUTES_Number)

numofplot = 6; 
if ~exist(path,'dir')
    mkdir(path);
end
data=zeros(size(totaldata,1),length(ATTRIBUTES_Number));
for m=1:length(ATTRIBUTES_Number)
    data(:,m)=totaldata(:,find(strcmp(attribute,ATTRIBUTES_Number(m))));
end
for i = 1:length(ATTRIBUTES_Number)
    if mod(i,numofplot) ==1
        fig = figure('visible','off','NumberTitle','off','Name',['histogram ' num2str(floor((i-1)/6))]); 
    end
    temp_data = data(:,i);
    [NaN_line, ~] = find(isnan(temp_data) == 1);
    temp_data(NaN_line,:) = [];
    subplot(2,3, mod(i-1,numofplot)+1);
    histogram(temp_data,50);
    title(ATTRIBUTES_Number(i));
    if mod(i,numofplot) == 0
        saveas(fig,[path 'histogram_' num2str(floor((i-1)/6)) '.jpg']);
    end
end
    if mod(i,numofplot) ==1
        figure('visible','off','NumberTitle','off','Name',['qqplot ' num2str(floor((i-1)/numofplot))]);
    end
    temp_data = data(:,i);
    [NaN_line, ~] = find(isnan(temp_data) == 1);
    temp_data(NaN_line, :) = [];
    qqplot(temp_data);
    title(ATTRIBUTES_Number(i));
    set(gca, 'xlabel', [], 'ylabel', []); 
    if mod(i,numofplot) == 0
        saveas(fig,[path 'qqplot_' num2str(floor((i-1)/numofplot)) '.jpg']);
    end
end


figure; 
for i = 1:length(ATTRIBUTES_Number)
    if mod(i,numofplot) ==1
        figure('visible','off','NumberTitle','off','Name',['boxplot ' num2str(floor((i-1)/numofplot))]); 
    end
    temp_data = data(:,i);
    [NaN_line, ~] = find(isnan(temp_data) == 1);
    temp_data(NaN_line, :) = [];
    boxplot(temp_data);
    title(ATTRIBUTES_Number(i));
    set(gca, 'xticklabel', []); 
        saveas(fig,[path 'boxplot_' num2str(floor((i-1)/numofplot)) '.jpg']);
    end
end

end
