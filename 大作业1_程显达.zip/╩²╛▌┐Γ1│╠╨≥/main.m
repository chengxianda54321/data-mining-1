clear;close all;
data=importdata('NFL Play by Play 2009-2017 (v4).csv');
attribute_index=1;
format long g;
p_index=1;
attribute= data.textdata(1,:);
attribute{1} = 'Date';
data.textdata(1,:)=[];
total_data=data.textdata;
total_data(:,102)=num2cell(data.data);
attribute_values = {'TimeUnder'; 'TimeSecs'; 'PlayTimeDiff'; 'yrdln'; 'yrdline100'; 'ydstogo';'ydsnet';'Yards.Gained';'AirYards';...
    'YardsAfterCatch';'FieldGoalDistance';'Penalty.Yards';'PosTeamScore';'DefTeamScore';'ScoreDiff';'AbsScoreDiff';...
    'posteam_timeouts_pre';'HomeTimeouts_Remaining_Pre';'AwayTimeouts_Remaining_Pre';'HomeTimeouts_Remaining_Post';...
    'AwayTimeouts_Remaining_Post';'No_Score_Prob';'Opp_Field_Goal_Prob';'Opp_Safety_Prob';'Opp_Touchdown_Prob';'Field_Goal_Prob';...
    'Safety_Prob';'Touchdown_Prob';'ExPoint_Prob';'TwoPoint_Prob';'ExpPts';'EPA';'airEPA';'yacEPA';'Home_WP_pre';'Away_WP_pre';...
    'Home_WP_post';'Away_WP_post';'Win_Prob';'WPA';'airWPA';'yacWPA'};

attribute_nominal={'Date';'GameID';'Drive';'qtr';'down';'time';'SideofField';'GoalToGo';'FirstDown';'posteam';'DefensiveTeam';...
    'desc';'PlayAttempted';'sp';'Touchdown';'ExPointResult';'TwoPointConv';'DefTwoPoint';'Safety';'Onsidekick';'PuntResult';...
    'PlayType';'Passer';'Passer_ID';'PassAttempt';'PassOutcome';'PassLength';'QBHit';'PassLocation';'InterceptionThrown';...
    'Interceptor';'Rusher';'Rusher_ID';'RushAttempt';'RunLocation';'RunGap';'Receiver';'Receiver_ID';'Reception';'ReturnResult';...
    'Returner';'BlockingPlayer';'Tackler1';'Tackler2';'FieldGoalResult';'Fumble';'RecFumbTeam';'RecFumbPlayer';'Sack';...
    'Challenge.Replay';'ChalReplayResult';'Accepted.Penalty';'PenalizedTeam';'PenaltyType';'PenalizedPlayer';'HomeTeam';...
    'AwayTeam';'Timeout_Indicator';'Timeout_Team';'Season'};

if ~exist('processed_nfl.mat','file')
    total_attribute_number=NaN*ones(size(total_data));
else
    load('processed_nfl.mat');
end
for i=1:length(attribute_nominal)
    now_attribute_index=find(strcmp(attribute,attribute_nominal{i}));
    now_attribute=total_data(:,now_attribute_index);
    raw_now_attribute=now_attribute;
    if isa (now_attribute{1},'double')
        now_attribute=cell2mat(now_attribute);
        now_attribute=num2str(now_attribute);
        [row,col]=size(now_attribute);
        now_attribute=mat2cell(now_attribute,ones(row,1),[col]);
    end
    %delete empty
    now_attribute(strcmp(now_attribute,'NA'))=[];
    unique_now_attribute=unique(now_attribute);
    save(['data/Nominal_Label/',attribute_nominal{i},'.mat'],'unique_now_attribute')
    unique_now_attribute_num=zeros(length(unique_now_attribute),1);
    if length(unique_now_attribute)>1000 || length(unique_now_attribute) ==2
        continue;
    end
    for j=1:length(unique_now_attribute)
        unique_now_attribute_num(j)=length(find(strcmp(now_attribute,unique_now_attribute(j))));
        if ~exist('processed_nfl.mat','file')
            total_attribute_number(strcmp(raw_now_attribute,unique_now_attribute{j}),now_attribute_index)=j;
        end
        fprintf('Task1:i=%d,j=%d,totali=%d,totalj=%d\n',i,j,length(attribute_nominal),length(unique_now_attribute))
    end
    total_num=sum(unique_now_attribute_num);
    if ~exist('result/attribute_nominal/','dir')
        mkdir('result/attribute_nominal/');
    end
    file_name=attribute_nominal{i};
    fid = fopen(['result/attribute_nominal/',file_name,'.txt'],'w');
    fprintf(fid,'frequence of %s attribute\n',file_name);
    fprintf(fid,'%20s      %20s      %20s\n','Type Description','Count','Percent');
    for j=1:length(unique_now_attribute)
    fprintf(fid,'%20s      %20d      %20.2f%%\n',unique_now_attribute{j},unique_now_attribute_num(j),100*unique_now_attribute_num(j)/total_num);
    end
    fclose(fid);
    fprintf('%d,%s\n',i,file_name);
end

temp_the_values = attribute_values;
all_NaN_line = [];

if ~exist('result/number_statistics/','dir')
    mkdir('result/number_statistics/');
end
fid = fopen(['result/number_statistics/','Data_abstract_of_attribute.txt'],'w');

fprintf(fid,'%20s    %20s   %20s    %20s    %20s    %20s    %20s\n',...
        'attribute','Maximium','Minimium:','Average', 'Median', 'Quartile', 'Missing data');
for i=1:length(attribute_values)
    now_attribute_index=find(strcmp(attribute,attribute_values{i}));
    now_attribute=total_data(:,now_attribute_index);
    now_attribute(strcmp(now_attribute,'NA'))={'nan'};
    now_attribute=str2double(now_attribute);
    if ~exist('processed_nfl.mat','file')
        total_attribute_number(:,now_attribute_index)=now_attribute;
    end
    temp_data = now_attribute;
    [NaN_line, ~] = find(isnan(temp_data) == 1);
    if (size(NaN_line, 1)/size(temp_data, 1) >0.1) 
        continue;
    end
    temp_data(NaN_line, :) = [];
    file_name=attribute_values{i};
    fprintf(fid,'statistics of %s attribute\n',file_name);
    fprintf(fid,'%20s:  %.5f         %.5f          %.5f          %.5f, %.5f  %.5f          %.5f\n',...
         file_name, max(temp_data),min(temp_data),mean(temp_data),median(temp_data),prctile(temp_data,25),prctile(temp_data,75),size(NaN_line, 1));
end
fclose(fid);
%%
if ~exist('processed_nfl.mat','file')
    total_attribute_number(:,102)=total_data{:,102};
    save('processed_nfl','total_attribute_number');
end
temp_the_values(all_NaN_line) = [];
myvisualization('result/number_orignal/',total_attribute_number,attribute,temp_the_values);   
for method =1:3
    if method == 1
        data = mypreprocessing(total_attribute_number, 1);
        dlmwrite('result/building_nfl_filled_by_maximium.txt', data, 'delimiter', '\t','precision', 6,'newline', 'pc')
        myvisualization('result/number_filledbymaxium/',total_attribute_number,attribute,temp_the_values);
    end
    if method ==2
        data = mypreprocessing(total_attribute_number, 2);
        dlmwrite('result/building_nfl_filled_by_attribute.txt', data, 'delimiter', '\t','precision', 6,'newline', 'pc')
        myvisualization('result/number_filledbyattributes/',data,attribute,temp_the_values);
    end
    if method ==3
        data3=zeros(size(total_attribute_number));
        blocksize=300;
        for k=1:blocksize
            disp(k)
            block_total_attribute_number=total_attribute_number((size(total_attribute_number,1)/blocksize)*(k-1)+1:(size(total_attribute_number,1)/blocksize)*k,:);
            data3((size(total_attribute_number,1)/blocksize)*(k-1)+1:(size(total_attribute_number,1)/blocksize)*k,:) = mypreprocessing(block_total_attribute_number, 3);
        end
        dlmwrite('result/building_nfl_filled_by_similarity.txt', data3, 'delimiter', '\t','precision', 6,'newline', 'pc')
        myvisualization('result/number_filledbysimilarity/',data3,attribute,temp_the_values);
    end
end

