function data = mypreprocessing(analytic_mat, method)

ATTRIBUTE_L = 1;
ATTRIBUTE_H = size(analytic_mat,2); %

[m, n] = size(analytic_mat);?
standard_line = [analytic_mat(4, ATTRIBUTE_L: ATTRIBUTE_H)]; 
switch(method)
    case 1 
        for i = 1: m
            disp(i)
            for j = ATTRIBUTE_L: ATTRIBUTE_H 
                if(isnan(analytic_mat(i, j)))
                    analytic_mat(i, j) = max([analytic_mat(:, j)]); 
            end
        end
        data = analytic_mat;
    case 2 
        cor_mat = correlation_mat_attribute(analytic_mat); 
        cor_size = size(cor_mat, 1); 
            disp(i)
            for j = ATTRIBUTE_L: ATTRIBUTE_H
                    if(isnan(analytic_mat(i, j)))
                    [~, index] = sort(cor_mat(j - ATTRIBUTE_L + 1, :));
                    index_list = fliplr(index); 
                    flag = 0; 
                    for k = 1: cor_size
                        ref_attr = index_list(k);
                            analytic_mat(i, j) = standard_line(j - ATTRIBUTE_L + 1) / standard_line(ref_attr) * ...
                                analytic_mat(i, ref_attr + ATTRIBUTE_L - 1); 
                            break;
                        end
                    end
                    if(flag == 0)
                        disp(['Insert fail at row ', num2str(i), ' col ', num2str(j)]);
                        return ;
                    end
                    end
            end
        end
        data = analytic_mat;
    case 3 
        sim_size = size(sim_mat, 1); 
            for j = ATTRIBUTE_L: ATTRIBUTE_H
                if(isnan(analytic_mat(i, j)))
                    [~, index_list] = sort(sim_mat(i, :));
                    flag = 0;
                    for k = 1: sim_size
                        ref_samp = index_list(k); 
                            analytic_mat(i, j) = analytic_mat(ref_samp, j); 
                            break;
                        end
                    end
                    if(flag == 0)
                        disp(['Insert fail at row ', num2str(i), ' col ', num2str(j)]);
                    end
                end
            end
        end
        data = analytic_mat;
    otherwise
        data = [];
        disp('Invalid method input.');
end

end

function cor_mat = correlation_mat_attribute(analytic_mat)
ATTRIBUTE_L = 1;
ATTRIBUTE_H = size(analytic_mat,2); 
COR_SIZE = ATTRIBUTE_H - ATTRIBUTE_L + 1;
cor_mat = ones(COR_SIZE, COR_SIZE); 
    for j = i + 1: ATTRIBUTE_H
        merge = [[analytic_mat(:, i)], [analytic_mat(:, j)]]; 
        merge(NaN_line, :) = []; 
        cor_indx = i - ATTRIBUTE_L + 1;
        cor_indy = j - ATTRIBUTE_L + 1;
          cor_mat(cor_indx, cor_indy) = corr(merge(:, 1), merge(:, 2));
          cor_mat(cor_indy, cor_indx) = cor_mat(cor_indx, cor_indy);
        else
            cor_mat(cor_indx, cor_indy) = 0; 
            cor_mat(cor_indy, cor_indx)=0;
        end
    end
end

end

function sim_mat = similarity_mat_sample(analytic_mat)
ATTRIBUTE_L = 1;
ATTRIBUTE_H = size(analytic_mat,2); 
SIM_SIZE = size(analytic_mat, 1);
sim_mat = ones(SIM_SIZE, SIM_SIZE) * 999; 
for i = 1: SIM_SIZE - 1
    for j = i + 1: SIM_SIZE
        merge = [[analytic_mat(i, ATTRIBUTE_L: ATTRIBUTE_H)]', ...
            [analytic_mat(j, ATTRIBUTE_L: ATTRIBUTE_H)]'];
        merge(NaN_line, :) = [];       
        sim_mat(i, j) = norm(merge(:, 1) - merge(:, 2));��
        sim_mat(j, i) = sim_mat(i, j); 
    end
end
end